#Alias
alias gn='geeknote'

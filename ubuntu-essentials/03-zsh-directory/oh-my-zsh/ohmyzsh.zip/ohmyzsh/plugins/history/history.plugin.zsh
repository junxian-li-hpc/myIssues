alias h='history'
alias hl='history | less'
alias hs='history | grep'
alias hsi='history | grep -i'
